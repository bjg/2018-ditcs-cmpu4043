import '../css/style.css';
import {Observable} from "rxjs/Rx";



//window.onload = function() {

    
    const btns = document.getElementsByClassName("Button");

    const stream$ = Observable.from(btns)
    .map(btn => Observable.fromEvent(btn, 'click')
    .mapTo(btn.value))
    .mergeAll()
    //.merge(Observable.fromEvent(document, 'keypress')
    //.pluck('key'));

    stream$.subscribe(key => {

        if(key == "c")
        {
            document.getElementById('number').value = "";
        }
        else if (key == "±")
        {
            document.getElementById('number').value = document.getElementById('number').value * -1;
        }
        else if(key == "=")
        {
            document.getElementById('number').value = eval(document.getElementById('number').value);
        }
        else
        {
            document.getElementById('number').value = document.getElementById('number').value + key;
        }
        
        console.log('TEST 1');
    });

    
//}