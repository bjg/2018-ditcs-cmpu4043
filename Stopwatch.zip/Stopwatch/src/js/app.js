import '../css/style.css';
import { timer } from 'rxjs';
import {Observable} from "rxjs/Rx";

//const source = timer(1000,100);


var angle = 0;
var angle1 = 0;
var start = "0";
var seconds = -1;
var hours = 0;
var minutes = 0;
var ms = 0;
var i = 0;
var j = 0;
var splitMin  = 0;
var splitHour = 0;
var splitSec  = 0;
var splitMili = 0;
var x2, y2;
var rows = 0;


var c = document.getElementById("canvas");
        var circ = c.getContext("2d"); 

var can = document.getElementById("canvas");
    var base = can.getContext("2d"); 
    base.clearRect(0, 0, canvas.width, canvas.height);
    base.beginPath();
    base.arc(200, 200, 200, 0, 2 * Math.PI);
    base.stroke();
    base.beginPath();
    base.arc(200, 200, 5, 0, 2 * Math.PI);
    base.stroke();

const btns = document.getElementsByClassName("Button");

    const stream$ = Observable.from(btns)
    .map(btn => Observable.fromEvent(btn, 'click')
    .mapTo(btn.value))
    .mergeAll()

    stream$.subscribe(key => {

        
        if(key == "Start")
        {
            start = 1;
        }
        if (key == "Stop")
        {
            start = 0;
        }
        if(key == "Split")
        {
            split();
        }
        if(key == "Reset")
        {
            reset();
        } 

    });

    setInterval( function(){
        angle1 = -Math.PI /2;
        angle1 += j * (Math.PI * 2 /60);
        angle = -Math.PI /2;
        angle += i * (Math.PI * 2 /60);

        stopwatch(angle, angle1, circ);
            //ms = 0;
            if(start == 1)
            {
                ms++;

                if(ms % 10 == 0)
                {
                    i++;
                }
                if(i % 60 == 0 && i != 0)
                {   i = 0;
                    j++;
                    console.log("i +++",i);
                    console.log(j);
                }
            }
        },100);

var stopwatch = function(angle, angle1, circ)
{

    if(start == 1)
    {
        //ms++;
        if(ms % 10 == 0)
        {
            ms = 0;
            seconds++;
        }

        //ms = 0;
        if(seconds == 60)
        {
            seconds = 0;
            minutes++;
        }else if(minutes == 600)
        {
            minutes = 0;
        }
        

        circ.clearRect(0, 0, canvas.width, canvas.height);
        circ.beginPath();
        circ.arc(200, 200, 200, 0, 2 * Math.PI);
        circ.stroke();
        circ.beginPath();
        circ.arc(200, 200, 5, 0, 2 * Math.PI);
        circ.stroke();

        

        circ.moveTo(200, 200);
        var x1 = 200 + 195 * Math.cos( angle );
        var y1 = 200 + 195 * Math.sin( angle );
        circ.lineTo(x1, y1);
        circ.stroke();
        circ.moveTo(200, 200);
        x2 = 200 + 180 * Math.cos( 0 + angle1 );
        y2 = 200 + 180 * Math.sin( 0 + angle1 );
        circ.lineTo(x2, y2);
        circ.stroke();
        
        digital.innerHTML = minutes + ' : ' + seconds + ' : ' + ms;
    }
}

var reset = function()
{
        rows = document.getElementById("table1").rows.length
        for(var z = rows -1; z >= 0; z--)
        {
            document.getElementById('table1').deleteRow(z);
        }
        
        circ.clearRect(0, 0, canvas.width, canvas.height);
        i         = 0;
        angle     = 0;
        start     = "0";
        stop      = "";
        seconds   = -1;
        hours     = 0;
        minutes   = 0;
        splitHour = 0;
        splitMin  = 0;
        splitSec  = 0;
        circ.clearRect(0, 0, canvas.width, canvas.height);
        circ.beginPath();
        circ.arc(200, 200, 200, 0, 2 * Math.PI);
        circ.stroke();
        circ.beginPath();
        circ.arc(200, 200, 5, 0, 2 * Math.PI);
        circ.stroke();
        digital.innerHTML = '0' + ' : ' + '0' + ' : ' + '0';  
}

var split = function()
{
    var table = document.getElementById('table1');
    if(splitHour == 0 && splitMin == 0 && splitSec == 0)
        {
            splitMin  = minutes;
            splitSec  = seconds;
            splitMili = ms;
        }else
        {
            splitMili = + (ms - splitMili);
            splitMin  = + (minutes - splitMin);
            splitSec  = + (seconds - splitSec);
        }
        if(rows < 5)
        {
        var tr = document.createElement('tr');
        var td = document.createElement('td');
        td.appendChild(document.createTextNode('Split - ' + splitMin + ' : ' + splitSec + ' : ' + splitMili));
        splitHour = hours;
        splitMin  = minutes;
        splitSec  = seconds;
        tr.appendChild(td);
        table.appendChild(tr);
        start = 1;
        rows++;
        }
}

//}
/*
        var radius = 200;            
        circ.translate(radius, radius);
        
        radius = radius * 0.95
        circ.font = radius*0.05 + "px arial";
        circ.textBaseline="middle";
        circ.textAlign="center";
        
        for(num = 1; num < 61; num++){
          ang = num * Math.PI / 30;
          circ.rotate(ang);
          circ.translate(0, -radius*0.95);
          circ.rotate(-ang);
          circ.fillText(num.toString(), 0, 0);
          circ.rotate(ang);
          circ.translate(0, radius*0.95);
          circ.rotate(-ang);
        }*/